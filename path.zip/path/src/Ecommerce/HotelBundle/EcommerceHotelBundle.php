<?php

namespace Ecommerce\HotelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EcommerceHotelBundle extends Bundle
{
}
