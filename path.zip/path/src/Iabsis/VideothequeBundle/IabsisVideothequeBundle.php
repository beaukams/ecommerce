<?php

namespace Iabsis\VideothequeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IabsisVideothequeBundle extends Bundle
{
}
